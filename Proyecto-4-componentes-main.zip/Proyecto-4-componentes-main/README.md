# ⚡ Proyecto de Práctica con Vite

Este proyecto es una **práctica de configuración y uso de Vite**, una herramienta moderna para desarrollo frontend que permite crear aplicaciones web rápidas y optimizadas.  
El objetivo es comprender cómo funciona el entorno de desarrollo, el bundling y la estructura de un proyecto moderno con **Vite**, **JavaScript**, **HTML** y **CSS**.

---

## 🚀 Objetivos del proyecto

- Aprender a **crear y configurar** un proyecto con Vite.  
- Practicar la **estructura modular** de componentes o scripts.  
- Implementar **recarga en tiempo real (HMR)** durante el desarrollo.  
- Preparar el proyecto para **build de producción** optimizada.  
- Familiarizarse con el flujo de trabajo moderno en frontend.

---

## 🧰 Tecnologías utilizadas

| Tecnología | Uso principal |
|-------------|----------------|
| **Vite** | Bundler y servidor de desarrollo rápido. |
| **HTML5** | Estructura y contenido base. |
| **CSS3 / Sass** | Estilos y diseño responsive. |
| **JavaScript (ES6+)** | Lógica, módulos y manipulación del DOM. |

---

🧩 Funcionalidades de ejemplo

Importación y exportación de módulos JavaScript.

Uso de módulos CSS o preprocesadores.

Recarga automática con HMR.

Estructura de carpetas clara y escalable.

Preparación para integración con frameworks (React, Vue, Svelte, etc.).

💡 Próximas mejoras

Añadir integración con React o Vue.

Implementar routing básico.

Configurar ESLint y Prettier.

Desplegar en Vercel o Netlify.
